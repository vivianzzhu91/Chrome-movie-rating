# Chrome-movie-rating-Extension
A chrome extension raw resource to get Douban, the most reliable Chinese movie rating website, rating and links to Youtube movies porfolio.
## Getting Stared
The extension would load automatically and shows the average rating and views by the movie title. If the movie has not yet been added to its own section, then this rating would not be available.

When clicked on the rating, it would open a new tab directing to the corresponding movie introduction page in Douban.

This extension used an open source Douban api to fetch movie-related data in Douban.
